#include "Nivel.h"

Nivel::Nivel()
{
    //ctor
}

Nivel::~Nivel()
{
    //dtor
}
