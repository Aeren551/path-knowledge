#include "Menu.h"

Menu::Menu()
{

}

int Menu::menuInicio(sf::RenderWindow* window)
{

}

int Menu::menuPause(sf::RenderWindow* window)
{

}



Menu::~Menu()
{
    //dtor
}
