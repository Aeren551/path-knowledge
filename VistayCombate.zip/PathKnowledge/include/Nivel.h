#ifndef NIVEL_H
#define NIVEL_H


class Nivel
{
    public:
        Nivel();
        virtual ~Nivel();

    protected:

    private:
};

#endif // NIVEL_H
